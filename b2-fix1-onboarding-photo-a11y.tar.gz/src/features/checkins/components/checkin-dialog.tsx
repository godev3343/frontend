// src/features/checkins/components/checkin-dialog.tsx
"use client";

import { standardSchemaResolver } from "@hookform/resolvers/standard-schema";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod/v4";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useUserLocation } from "@/features/map/hooks/use-user-location";
import {
  CHECKIN_RADIUS_METERS,
  haversineMeters,
} from "@/features/map/lib/distance";
import type { PlaceDetail } from "@/features/map/schemas";
import { ImagePicker } from "@/features/media/image-picker";
import type { UploadPhase } from "@/features/media/use-image-upload";

import { useCreateCheckin } from "../hooks/use-create-checkin";

const formSchema = z.object({
  comment: z.string().max(500).default(""),
});

type FormValues = z.input<typeof formSchema>;

type Props = {
  place: PlaceDetail;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
};

/**
 * Фазы, при которых сабмит чек-ина должен быть заблокирован.
 * Бэк отбивает 400 photo_not_ready, если photo_key передан, но MediaAsset
 * на бэке ещё processing/uploading. Безопасно сабмитить только при idle/ready/error.
 */
function isPhotoBusy(phase: UploadPhase): boolean {
  return (
    phase === "compressing" ||
    phase === "presigning" ||
    phase === "uploading" ||
    phase === "confirming" ||
    phase === "processing"
  );
}

export function CheckinDialog({ place, open, onOpenChange, onSuccess }: Props) {
  const { status, coords, request } = useUserLocation({
    strict: true,
    auto: false,
  });

  const [photoUrl, setPhotoUrl] = useState<string>("");
  const [photoKey, setPhotoKey] = useState<string | null>(null);
  const [photoPhase, setPhotoPhase] = useState<UploadPhase>("idle");

  const form = useForm<
    z.input<typeof formSchema>,
    unknown,
    z.output<typeof formSchema>
  >({
    resolver: standardSchemaResolver(formSchema),
    defaultValues: { comment: "" },
  });

  const createCheckinMut = useCreateCheckin();

  useEffect(() => {
    if (open) request();
  }, [open, request]);

  const handleOpenChange = (next: boolean) => {
    if (!next) {
      form.reset({ comment: "" });
      setPhotoUrl("");
      setPhotoKey(null);
      setPhotoPhase("idle");
    }
    onOpenChange(next);
  };

  const distance = useMemo(() => {
    if (!coords) return null;
    return haversineMeters(
      { lat: coords.lat, lng: coords.lng },
      place.location,
    );
  }, [coords, place.location]);

  const isInRange =
    coords !== null && distance !== null && distance <= CHECKIN_RADIUS_METERS;

  const onSubmit = (values: FormValues) => {
    if (!coords) {
      toast.error("Не удалось определить вашу геопозицию");
      return;
    }
    const d = haversineMeters(
      { lat: coords.lat, lng: coords.lng },
      place.location,
    );
    if (d > CHECKIN_RADIUS_METERS) {
      toast.error("Подойдите ближе к месту (≤100м)");
      return;
    }
    // Защита от race: если фото всё ещё обрабатывается — не шлём.
    // Кнопка должна быть disabled, но это защита на случай если её
    // удалось нажать (a11y/keyboard).
    if (isPhotoBusy(photoPhase)) {
      toast.error("Дождитесь окончания обработки фото");
      return;
    }

    const comment = (values.comment ?? "").trim();

    createCheckinMut.mutate(
      {
        place_id: place.id,
        lat: coords.lat,
        lng: coords.lng,
        photo_key: photoKey,
        comment: comment.length > 0 ? comment : null,
      },
      {
        onSuccess: () => {
          handleOpenChange(false);
          onSuccess?.();
        },
      },
    );
  };

  const photoBusy = isPhotoBusy(photoPhase);
  const submitDisabled =
    createCheckinMut.isPending ||
    status === "requesting" ||
    !coords ||
    !isInRange ||
    photoBusy;

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="z-[60] sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Чек-ин в {place.name}</DialogTitle>
          <DialogDescription>
            Добавьте фото и комментарий — необязательно.
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex flex-col gap-4"
        >
          <div className="flex flex-col gap-2">
            <Label>Фото</Label>
            <ImagePicker
              purpose="checkin"
              value={photoUrl}
              onChange={(url, key) => {
                setPhotoUrl(url);
                setPhotoKey(key);
              }}
              on_phase_change={setPhotoPhase}
              allow_camera
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="checkin-comment">Комментарий</Label>
            <Textarea
              id="checkin-comment"
              placeholder="Что здесь сейчас?"
              rows={3}
              {...form.register("comment")}
            />
            {form.formState.errors.comment ? (
              <p className="text-destructive text-xs">
                {form.formState.errors.comment.message}
              </p>
            ) : null}
          </div>

          {status === "requesting" ? (
            <p className="text-muted-foreground text-xs">
              Определяем вашу геопозицию...
            </p>
          ) : null}
          {(status === "denied" || status === "error") && !coords ? (
            <p className="text-destructive text-xs">
              Не удалось получить геопозицию. Разрешите доступ в браузере.
            </p>
          ) : null}
          {coords && distance !== null && !isInRange ? (
            <p className="text-destructive text-xs">
              Вы слишком далеко от места ({Math.round(distance)} м). Подойдите
              ближе.
            </p>
          ) : null}
          {photoBusy ? (
            <p className="text-muted-foreground text-xs">
              Дождитесь окончания обработки фото перед чек-ином.
            </p>
          ) : null}

          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => handleOpenChange(false)}
              disabled={createCheckinMut.isPending}
            >
              Отмена
            </Button>
            <Button type="submit" disabled={submitDisabled}>
              {createCheckinMut.isPending ? "Создаём..." : "Чек-ин"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
